package com.mysms.spend

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { App() } } }
    }
}

private val inr: NumberFormat = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
private val dateFmt = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
private val RED = Color(0xFFC62828)
private val GREEN = Color(0xFF2E7D32)

@Composable
fun App() {
    val ctx = LocalContext.current
    var granted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_SMS) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted = it }

    if (!granted) {
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("SMS Spend", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(12.dp))
            Text("This app reads your bank SMS on this phone only, to total your spends and credits. Nothing is uploaded.")
            Spacer(Modifier.height(20.dp))
            Button(onClick = { launcher.launch(Manifest.permission.READ_SMS) }) {
                Text("Allow SMS access")
            }
        }
        return
    }

    var all by remember { mutableStateOf<List<Txn>?>(null) }
    LaunchedEffect(Unit) {
        all = withContext(Dispatchers.IO) { SmsParser.parseAll(SmsReader.readInbox(ctx)) }
    }

    val txns = all
    if (txns == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
    } else {
        SummaryScreen(txns)
    }
}

@Composable
private fun SummaryScreen(all: List<Txn>) {
    var period by remember { mutableStateOf(Period.MONTH) }
    var query by remember { mutableStateOf("") }
    var typeFilter by remember { mutableStateOf<TxnType?>(null) }
    var largestFirst by remember { mutableStateOf(false) }
    var openPeriod by remember { mutableStateOf<String?>(null) }
    var openTxn by remember { mutableStateOf<Long?>(null) }

    val filtered = remember(all, query, typeFilter) {
        all.filter { (typeFilter == null || it.type == typeFilter) && Periods.matches(it, query) }
    }
    val groups = remember(filtered, period) { Periods.group(filtered, period) }
    val totalOut = filtered.filter { it.type == TxnType.DEBIT }.sumOf { it.amount }
    val totalIn = filtered.filter { it.type == TxnType.CREDIT }.sumOf { it.amount }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Account summary", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }

        // Search
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Search SMS (zomato, hdfc, 1234, >5000)") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear")
                        }
                    }
                }
            )
        }

        // Weekly / Monthly / Yearly
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Period.values().forEach { p ->
                    FilterChip(
                        selected = period == p,
                        onClick = { period = p; openPeriod = null; openTxn = null },
                        label = { Text(p.title) }
                    )
                }
            }
        }

        // Type + sort filters
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { FilterChip(selected = typeFilter == null, onClick = { typeFilter = null }, label = { Text("All") }) }
                item { FilterChip(selected = typeFilter == TxnType.DEBIT, onClick = { typeFilter = TxnType.DEBIT }, label = { Text("Spent") }) }
                item { FilterChip(selected = typeFilter == TxnType.CREDIT, onClick = { typeFilter = TxnType.CREDIT }, label = { Text("Credited") }) }
                item { FilterChip(selected = largestFirst, onClick = { largestFirst = !largestFirst }, label = { Text("Largest first") }) }
            }
        }

        // Overall totals for what is currently shown
        item {
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column { Text("Spent"); Text(inr.format(totalOut), color = RED, fontWeight = FontWeight.Bold) }
                    Column { Text("Credited"); Text(inr.format(totalIn), color = GREEN, fontWeight = FontWeight.Bold) }
                    Column { Text("SMS"); Text("${filtered.size}", fontWeight = FontWeight.Bold) }
                }
            }
        }

        if (groups.isEmpty()) item { Text("No matching bank messages.") }

        items(groups, key = { it.key }) { g ->
            PeriodCard(
                g = g,
                expanded = openPeriod == g.key,
                onToggle = { openPeriod = if (openPeriod == g.key) null else g.key; openTxn = null },
                largestFirst = largestFirst,
                openTxn = openTxn,
                onOpenTxn = { openTxn = it }
            )
        }
    }
}

@Composable
private fun PeriodCard(
    g: PeriodSummary,
    expanded: Boolean,
    onToggle: () -> Unit,
    largestFirst: Boolean,
    openTxn: Long?,
    onOpenTxn: (Long?) -> Unit
) {
    var limit by remember(g.key) { mutableStateOf(30) }

    Card(Modifier.fillMaxWidth()) {
        Column {
            Column(Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(16.dp)) {
                Text(g.label, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Spent ${inr.format(g.totalDebit)}", color = RED)
                    Text("Credited ${inr.format(g.totalCredit)}", color = GREEN)
                }
                Text(
                    "${g.count} SMS  ·  Net ${inr.format(g.net)}  ·  " +
                        if (expanded) "tap to collapse" else "tap to expand",
                    style = MaterialTheme.typography.bodySmall
                )
            }

            if (expanded) {
                Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 12.dp)) {
                    HorizontalDivider()

                    Text("By account", style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 8.dp))
                    g.accounts.forEach { a ->
                        Text(
                            "${a.key}: spent ${inr.format(a.totalDebit)}, credited ${inr.format(a.totalCredit)}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    Text("Messages", style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 10.dp))
                    val list = if (largestFirst) g.txns.sortedByDescending { it.amount }
                    else g.txns.sortedByDescending { it.timeMillis }

                    list.take(limit).forEach { t ->
                        TxnRow(t, open = openTxn == t.uid) {
                            onOpenTxn(if (openTxn == t.uid) null else t.uid)
                        }
                    }
                    if (list.size > limit) {
                        TextButton(onClick = { limit += 30 }) { Text("Show more (${list.size - limit} left)") }
                    }
                }
            }
        }
    }
}

@Composable
private fun TxnRow(t: Txn, open: Boolean, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val isOut = t.type == TxnType.DEBIT

    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 6.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(t.party ?: t.sender.ifBlank { "Bank SMS" })
                Text(
                    "${dateFmt.format(Date(t.timeMillis))} · ${t.accountKey}",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Text(
                (if (isOut) "- " else "+ ") + inr.format(t.amount),
                color = if (isOut) RED else GREEN,
                fontWeight = FontWeight.Medium
            )
        }

        if (open) {
            Surface(
                tonalElevation = 2.dp,
                shape = MaterialTheme.shapes.small,
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
            ) {
                Column(Modifier.padding(10.dp)) {
                    Text("SMS from ${t.sender}", style = MaterialTheme.typography.labelSmall)
                    Spacer(Modifier.height(4.dp))
                    SelectionContainer { Text(t.raw, style = MaterialTheme.typography.bodyMedium) }
                    Row {
                        TextButton(onClick = { openSms(ctx, t) }) { Text("Open in Messages") }
                        TextButton(onClick = {
                            clipboard.setText(AnnotatedString(t.raw))
                            Toast.makeText(ctx, "SMS copied", Toast.LENGTH_SHORT).show()
                        }) { Text("Copy") }
                    }
                }
            }
        }
    }
}

/**
 * Best effort: Android has no standard way to jump to one exact SMS, so this opens the
 * conversation with the sender (or just the Messages app). The full text is always shown in-app.
 */
private fun openSms(ctx: Context, t: Txn) {
    val attempts = listOfNotNull(
        t.threadId.takeIf { it > 0 }?.let {
            Intent(Intent.ACTION_VIEW, Uri.parse("content://mms-sms/conversations/$it"))
        },
        Intent(Intent.ACTION_VIEW, Uri.parse("smsto:" + Uri.encode(t.sender))),
        Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING)
    )
    for (intent in attempts) {
        try {
            ctx.startActivity(intent)
            return
        } catch (e: Exception) {
            // try the next option
        }
    }
    Toast.makeText(ctx, "Could not open the Messages app", Toast.LENGTH_SHORT).show()
}
