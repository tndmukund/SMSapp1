package com.mysms.spend

enum class TxnType { DEBIT, CREDIT }

data class RawSms(
    val sender: String,
    val body: String,
    val timeMillis: Long,
    val id: Long = 0,        // row id in the phone's SMS database
    val threadId: Long = 0   // conversation id in the phone's SMS database
)

data class Txn(
    val type: TxnType,
    val amount: Double,
    val bank: String,          // e.g. HDFC, SBI, ICICI (from sender id)
    val accountKind: String,   // "Account", "Credit Card", "Debit Card", "UPI/Wallet"
    val last4: String?,        // last digits of account / card if present
    val party: String?,        // merchant / payee / payer if detected
    val balance: Double?,      // available balance if present
    val timeMillis: Long,
    val raw: String,
    val sender: String = "",
    val smsId: Long = 0,
    val threadId: Long = 0
) {
    /** Key used to group the same account / card together. */
    val accountKey: String
        get() = "$bank • $accountKind" + (last4?.let { " ••$it" } ?: "")

    /** Stable id for UI state (which row is expanded). */
    val uid: Long
        get() = if (smsId > 0) smsId else timeMillis xor raw.hashCode().toLong()
}

data class AccountSummary(
    val key: String,
    val totalDebit: Double,
    val totalCredit: Double,
    val count: Int,
    val lastBalance: Double?,
    val txns: List<Txn>
) {
    val net: Double get() = totalCredit - totalDebit
}
