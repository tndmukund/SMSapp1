package com.mysms.spend

import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters
import java.util.Locale

enum class Period(val title: String) {
    WEEK("Weekly"), MONTH("Monthly"), YEAR("Yearly"), ALL("All time")
}

data class PeriodSummary(
    val key: String,
    val label: String,
    val start: LocalDate,
    val totalDebit: Double,
    val totalCredit: Double,
    val txns: List<Txn>,
    val accounts: List<AccountSummary>
) {
    val count: Int get() = txns.size
    val net: Double get() = totalCredit - totalDebit
}

/** Weekly / monthly / yearly grouping and search. Pure Kotlin, unit tested. */
object Periods {

    /** First day of the week (Monday), month or year that contains [timeMillis]. */
    fun startOf(timeMillis: Long, period: Period, zone: ZoneId = ZoneId.systemDefault()): LocalDate {
        val d = Instant.ofEpochMilli(timeMillis).atZone(zone).toLocalDate()
        return when (period) {
            Period.WEEK -> d.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            Period.MONTH -> d.withDayOfMonth(1)
            Period.YEAR -> d.withDayOfYear(1)
            Period.ALL -> LocalDate.of(2000, 1, 1)
        }
    }

    fun label(start: LocalDate, period: Period): String = when (period) {
        Period.ALL -> "All time"
        Period.YEAR -> start.year.toString()
        Period.MONTH -> start.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH))
        Period.WEEK -> {
            val end = start.plusDays(6)
            val f = DateTimeFormatter.ofPattern("d MMM", Locale.ENGLISH)
            "${start.format(f)} – ${end.format(f)} ${end.year}"
        }
    }

    fun group(
        txns: List<Txn>,
        period: Period,
        zone: ZoneId = ZoneId.systemDefault()
    ): List<PeriodSummary> =
        txns.groupBy { startOf(it.timeMillis, period, zone) }
            .map { (start, items) ->
                PeriodSummary(
                    key = "${period.name}-$start",
                    label = label(start, period),
                    start = start,
                    totalDebit = items.filter { it.type == TxnType.DEBIT }.sumOf { it.amount },
                    totalCredit = items.filter { it.type == TxnType.CREDIT }.sumOf { it.amount },
                    txns = items,
                    accounts = SmsParser.summarize(items)
                )
            }
            .sortedByDescending { it.start }

    /**
     * Search across SMS text, merchant, bank, card/account digits and amount.
     * Words are ANDed. Use ">5000" or "<500" to filter by amount, e.g. "zomato >300".
     */
    fun matches(t: Txn, query: String): Boolean {
        val tokens = query.trim().lowercase().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return true

        val hay = buildString {
            append(t.raw.lowercase()).append(' ')
            append(t.sender.lowercase()).append(' ')
            append(t.bank.lowercase()).append(' ')
            append(t.accountKind.lowercase()).append(' ')
            t.last4?.let { append(it).append(' ') }
            t.party?.let { append(it.lowercase()).append(' ') }
            append(String.format(Locale.ENGLISH, "%.2f", t.amount)).append(' ')
            append(t.amount.toLong())
        }

        return tokens.all { tok ->
            val num = tok.drop(1).replace(",", "").toDoubleOrNull()
            when {
                tok == ">" || tok == "<" -> true // still typing
                tok.startsWith(">") && num != null -> t.amount > num
                tok.startsWith("<") && num != null -> t.amount < num
                else -> hay.contains(tok.replace(",", ""))
            }
        }
    }
}
