package com.mysms.spend

import org.junit.Assert.*
import org.junit.Test

class AccountGroupingTest {

    private fun t(type: TxnType, amt: Double, bank: String, kind: String, last4: String?) =
        Txn(type, amt, bank, kind, last4, null, null, 1L, "x")

    @Test fun sameBankAccountIsOneGroup() {
        val list = SmsParser.normalize(
            listOf(
                t(TxnType.DEBIT, 100.0, "ICICI", "UPI/Wallet", "409"),
                t(TxnType.CREDIT, 50.0, "ICICI", "Account", null),
                t(TxnType.DEBIT, 10.0, "ICICI", "Card", "409"),
                t(TxnType.DEBIT, 5.0, "ICICI", "Credit Card", "8005"),
                t(TxnType.DEBIT, 7.0, "ICICI", "Credit Card", null)
            )
        )
        val s = SmsParser.summarize(list)
        assertEquals(2, s.size)

        val acct = s.first { it.key == "ICICI A/c ••409" }
        assertEquals(110.0, acct.totalDebit, 0.001)
        assertEquals(50.0, acct.totalCredit, 0.001)
        assertEquals(3, acct.count)

        val cc = s.first { it.key == "ICICI Credit Card ••8005" }
        assertEquals(12.0, cc.totalDebit, 0.001)
    }

    @Test fun twoCardsKeepMissingDigitsSeparate() {
        val list = SmsParser.normalize(
            listOf(
                t(TxnType.DEBIT, 1.0, "HSBC", "Credit Card", "7208"),
                t(TxnType.DEBIT, 2.0, "HSBC", "Credit Card", "1111"),
                t(TxnType.DEBIT, 3.0, "HSBC", "Credit Card", null)
            )
        )
        assertEquals(3, SmsParser.summarize(list).size)
    }

    @Test fun senderNamesMapToBanks() {
        val yono = SmsParser.parse(RawSms("VM-SBYONO-S", "Rs.500 debited from A/c XX4592 on 01-10-26", 1L))!!
        assertEquals("SBI", yono.bank)
        val hsbc = SmsParser.parse(RawSms("JM-HSBCIN-S", "Rs.900 spent on HSBC Credit Card XX7208 at AMAZON", 1L))!!
        assertEquals("HSBC", hsbc.bank)
    }
}
